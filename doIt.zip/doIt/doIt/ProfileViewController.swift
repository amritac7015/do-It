//
//  ProfileViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/22/24.
//

import UIKit
import UserNotifications

class ProfileViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var changePhotoButton: UIButton!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var notificationSwitch: UISwitch!
    
    // MARK: - Properties
        var user: User!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            self.navigationItem.title = "Profile"
            
            // Load user data (you might load this from UserDefaults or another data source)
            loadUserProfile()
            
            // Configure the UI elements
            configureUI()
            
            // Handle image tap to change the profile picture
            let imageTapGesture = UITapGestureRecognizer(target: self, action: #selector(changePhotoButtonTapped))
            profileImageView.addGestureRecognizer(imageTapGesture)
            profileImageView.isUserInteractionEnabled = true
        }
        
        // MARK: - UI Configuration
        private func configureUI() {
            profileImageView.layer.cornerRadius = profileImageView.frame.width / 2
            profileImageView.clipsToBounds = true
            profileImageView.contentMode = .scaleAspectFill
            
            changePhotoButton.layer.cornerRadius = 8
            usernameTextField.text = user.username
            notificationSwitch.isOn = user.notificationsEnabled
        }
        
        // MARK: - Load User Data
        private func loadUserProfile() {
            // Load user data (example using UserDefaults)
            if let savedUser = DataManager.shared.loadUser() {
                user = savedUser
            } else {
                user = User(username: "NewUser", profileImage: nil, notificationsEnabled: false)
            }
            
            // Load profile image if available
            if let profileImageData = user.profileImage {
                profileImageView.image = UIImage(data: profileImageData)
            } else {
                profileImageView.image = UIImage(systemName: "person.circle")
            }
        }
        
        // MARK: - Actions
        @IBAction func changePhotoButtonTapped() {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            present(imagePicker, animated: true, completion: nil)
        }
        
        @IBAction func saveButtonTapped(_ sender: UIButton) {
            // Validate and save the username
            guard let username = usernameTextField.text, !username.isEmpty else {
                presentAlert(title: "Invalid Username", message: "Please enter a valid username.")
                return
            }
            
            user.username = username
            user.notificationsEnabled = notificationSwitch.isOn
            
            // Save user data
            DataManager.shared.saveUser(user)
            
            // Request notification permissions if enabled
            if user.notificationsEnabled {
                requestNotificationPermission()
            }
            
            presentAlert(title: "Profile Updated", message: "Your profile has been updated successfully.")
        }
        
        private func requestNotificationPermission() {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
                DispatchQueue.main.async {
                    if granted {
                        print("Notifications enabled.")
                    } else {
                        self.notificationSwitch.isOn = false
                        print("Notifications disabled.")
                    }
                }
            }
        }
        
        // MARK: - Helper Methods
        private func presentAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
        }
    }

// MARK: - UIImagePickerControllerDelegate & UINavigationControllerDelegate

extension ProfileViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        if let selectedImage = info[.originalImage] as? UIImage {
            profileImageView.image = selectedImage
            user.profileImage = selectedImage.pngData() // Save as Data for persistence
            
            // Save the updated user with the new profile image
            DataManager.shared.saveUser(user)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

