//
//  Step.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/19/24.
//

import Foundation

struct Step: Codable {
    var name: String
    var description: String?
    var isCompleted: Bool
    var completionDetails: String?
    var imageData: Data?
    
    init(name: String, description: String?, isCompleted: Bool = false, completionDetails: String? = nil, imageData: Data? = nil) {
        self.name = name
        self.description = description
        self.isCompleted = isCompleted
        self.completionDetails = completionDetails
        self.imageData = imageData
    }
}
