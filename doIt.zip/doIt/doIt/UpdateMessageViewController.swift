//
//  UpdateMessageViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/22/24.
//
import UIKit

class UpdateMessageViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
       @IBOutlet weak var detailedMessageTextView: UITextView!
       @IBOutlet weak var homeButton: UIButton! // Outlet for the Home button
       
    // MARK: - Properties
       var post: Post! // Now using a `Post` object directly
       
       override func viewDidLoad() {
           super.viewDidLoad()
           self.navigationItem.title = "Post Details"
           
           // Ensure the post is available
           guard post != nil else {
               fatalError("UpdateMessageViewController requires a Post object.")
           }
           
           // Display the post details.
           authorLabel.text = "Posted by: \(post.author.username)"
           dateLabel.text = DateFormatter.localizedString(from: post.date, dateStyle: .medium, timeStyle: .short)
           detailedMessageTextView.text = post.detailedMessage
           
           configureHomeButton()
       }
       
       private func configureHomeButton() {
           homeButton.layer.cornerRadius = 8
           homeButton.addTarget(self, action: #selector(homeButtonTapped), for: .touchUpInside)
       }
       
       @objc private func homeButtonTapped() {
           // Navigate back to the home screen
           navigationController?.popToRootViewController(animated: true)
       }
   }
