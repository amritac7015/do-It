//
//  Post.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/22/24.
//

import Foundation

struct Post: Codable {
    let id: UUID
    let author: User
    let content: String
    var detailedMessage: String?
    let date: Date
    
    init(author: User, content: String, detailedMessage: String?, date: Date = Date()) {
        self.id = UUID()
        self.author = author
        self.content = content
        self.detailedMessage = detailedMessage
        self.date = Date()
    }
}
