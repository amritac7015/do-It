//
//  User.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/19/24.
//

import Foundation
struct User: Codable {
    var username: String
        var profileImage: Data? // Store image data as Data
        var notificationsEnabled: Bool
}
