//
//  Activity.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/19/24.
//

import Foundation
struct Activity: Codable, Equatable {
    var id: UUID
    var name: String
    var description: String?
    var collaborators: [User]
    var steps: [Step]
    var posts: [Post] // New Property for Posts

   
    init(name: String, description: String? = nil, collaborators: [User] = [], steps: [Step] = [], posts: [Post] = []) {
            self.id = UUID()
            self.name = name
            self.description = description
            self.collaborators = collaborators
            self.steps = steps
            self.posts = posts
        }
    
    static func == (lhs: Activity, rhs: Activity) -> Bool {
          return lhs.id == rhs.id
      }
    
    }
