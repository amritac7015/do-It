//
//  Notification.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/22/24.
//

import Foundation

struct NotificationItem: Codable {
    let id: UUID
    let type: NotificationType
    let message: String
    var detailedMessage: String // Add this property for the full content
    let date: Date
    var post: Post?
    var author: String // Add this property for the author's name

    
    enum NotificationType: String, Codable {
        case stepCompleted
        case postAdded
    }
    
    init(type: NotificationType, message: String, detailedMessage: String, date: Date = Date(), author: String) {
        self.id = UUID()
        self.type = type
        self.message = message
        self.detailedMessage = detailedMessage
        self.date = Date()
        self.author = author
        
    }
}
