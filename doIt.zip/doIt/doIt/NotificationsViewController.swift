//
//  NotificationsViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/22/24.
//

import UIKit

class NotificationsViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var notificationsTableView: UITableView!
    
    // MARK: - Properties
       var notifications: [NotificationItem] = []
       
       // MARK: - View Lifecycle
       override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
           loadNotifications() // Reload notifications when the view appears
       }

       override func viewDidLoad() {
           super.viewDidLoad()
           
           self.navigationItem.title = "Updates"
           
           // Set up TableView
           notificationsTableView.delegate = self
           notificationsTableView.dataSource = self
           notificationsTableView.register(UITableViewCell.self, forCellReuseIdentifier: "NotificationCell")
           
           // Load Notifications
           loadNotifications()
           
           // Optional: Add Refresh Control
           let refreshControl = UIRefreshControl()
           refreshControl.addTarget(self, action: #selector(refreshNotifications), for: .valueChanged)
           notificationsTableView.refreshControl = refreshControl
       }
       
       // MARK: - Data Loading
       private func loadNotifications() {
           notifications = DataManager.shared.loadNotifications()
           // Sort notifications by date (most recent first)
           notifications.sort { $0.date > $1.date }
           notificationsTableView.reloadData()
       }
       
       @objc private func refreshNotifications() {
           loadNotifications()
           notificationsTableView.refreshControl?.endRefreshing()
       }
   }

   // MARK: - UITableViewDataSource

   extension NotificationsViewController: UITableViewDataSource {
       
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return notifications.count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationCell", for: indexPath)
           let notification = notifications[indexPath.row]
           
           cell.textLabel?.text = notification.message
           
           // Format the date
           let formatter = DateFormatter()
           formatter.dateStyle = .short
           formatter.timeStyle = .short
           cell.detailTextLabel?.text = formatter.string(from: notification.date)
           
           // Customize appearance based on notification type
           switch notification.type {
           case .stepCompleted:
               cell.imageView?.image = UIImage(systemName: "checkmark.circle")
               cell.imageView?.tintColor = .systemGreen
           case .postAdded:
               cell.imageView?.image = UIImage(systemName: "doc.text")
               cell.imageView?.tintColor = .systemBlue
           }
           
           return cell
       }
   }

   // MARK: - UITableViewDelegate

   extension NotificationsViewController: UITableViewDelegate {
       
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           print("Row selected at index: \(indexPath.row)") // Debug print to check if the method is triggered.
           
           let selectedNotification = notifications[indexPath.row]
           
           // Ensure that the notification has a related post
           guard let post = selectedNotification.post else {
               print("No post found for the selected notification.")
               return
           }
           
           // Print the post content for debugging
           print("Navigating to post with content: \(post.content)")
           
           // Navigate to the UpdateMessageViewController to display the post details
           let storyboard = UIStoryboard(name: "Main", bundle: nil)
           if let updateMessageVC = storyboard.instantiateViewController(withIdentifier: "UpdateMessageViewController") as? UpdateMessageViewController {
               updateMessageVC.post = post
               navigationController?.pushViewController(updateMessageVC, animated: true)
           } else {
               print("Failed to instantiate UpdateMessageViewController.")
           }
           
           tableView.deselectRow(at: indexPath, animated: true)
       }
   }
