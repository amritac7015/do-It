//
//  ActivityDetailViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/19/24.
//

import UIKit


class ActivityDetailViewController: UIViewController {
    
    @IBOutlet weak var activityDescriptionLabel: UILabel!
    @IBOutlet weak var detailsTableView: UITableView!
    @IBOutlet weak var progressBar: UIProgressView! // Added Progress Bar Outlet
    
    // MARK: - Properties
        var activity: Activity!
        var notifications: [NotificationItem] = []
        
        // MARK: - Section Enumeration
        enum DetailSection: Int, CaseIterable {
            case steps = 0
            case collaborators
            case notifications
            
            var title: String {
                switch self {
                case .steps:
                    return "Steps"
                case .collaborators:
                    return "Collaborators"
                case .notifications:
                    return "Updates"
                }
            }
        }
        
        // MARK: - View Lifecycle
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Safety check
            guard activity != nil else {
                fatalError("ActivityDetailViewController requires an Activity to function.")
            }
            
            self.navigationItem.title = activity.name
            activityDescriptionLabel.text = activity.description ?? "No description available."
            
            detailsTableView.delegate = self
            detailsTableView.dataSource = self
            
            loadActivityNotifications()
            updateProgress()
        }
        
        // MARK: - Helper Methods
        private func loadActivityNotifications() {
            // Load all notifications and filter those related to this activity
            notifications = DataManager.shared.loadNotifications().filter {
                $0.message.contains(activity.name)
            }
            detailsTableView.reloadData()
        }

        private func updateProgress() {
            let totalSteps = activity.steps.count
            let completedSteps = activity.steps.filter { $0.isCompleted }.count
            
            let progress = totalSteps > 0 ? Float(completedSteps) / Float(totalSteps) : 0.0
            progressBar.setProgress(progress, animated: true)
            
            if completedSteps == totalSteps && totalSteps > 0 {
                presentCompletionMessage()
            }
        }
        
        private func presentCompletionMessage() {
            let alertController = UIAlertController(
                title: "Congratulations!",
                message: "You have completed all steps for this activity.",
                preferredStyle: .alert
            )
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
        }

        private func navigateToStepDetail(step: Step, at index: Int) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let stepDetailVC = storyboard.instantiateViewController(withIdentifier: "StepDetailViewController") as? StepDetailViewController {
                stepDetailVC.step = step
                stepDetailVC.stepIndex = index
                stepDetailVC.delegate = self
                navigationController?.pushViewController(stepDetailVC, animated: true)
            }
        }
        
        private func navigateToUpdateDetails(post: Post) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let updateMessageVC = storyboard.instantiateViewController(withIdentifier: "UpdateMessageViewController") as? UpdateMessageViewController {
                updateMessageVC.post = post
                navigationController?.pushViewController(updateMessageVC, animated: true)
            }
        }

        func removeCollaborator(at index: Int) {
            activity.collaborators.remove(at: index)
            detailsTableView.reloadSections(IndexSet(integer: DetailSection.collaborators.rawValue), with: .automatic)
            saveActivityChanges()
        }
        
        func saveActivityChanges() {
            DataManager.shared.updateActivity(activity)
        }
    }

    // MARK: - UITableViewDataSource and UITableViewDelegate

    extension ActivityDetailViewController: UITableViewDataSource, UITableViewDelegate {
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return DetailSection.allCases.count
        }
        
        func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            guard let detailSection = DetailSection(rawValue: section) else { return nil }
            return detailSection.title
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            guard let detailSection = DetailSection(rawValue: section) else { return 0 }
            
            switch detailSection {
            case .steps:
                return activity.steps.count
            case .collaborators:
                return activity.collaborators.count
            case .notifications:
                return notifications.count
            }
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            guard let detailSection = DetailSection(rawValue: indexPath.section) else {
                return UITableViewCell()
            }
            
            switch detailSection {
            case .steps:
                let step = activity.steps[indexPath.row]
                let cell = tableView.dequeueReusableCell(withIdentifier: "StepCell", for: indexPath)
                cell.textLabel?.text = step.name
                cell.detailTextLabel?.text = step.description
                cell.accessoryType = step.isCompleted ? .checkmark : .none
                return cell
                
            case .collaborators:
                let collaborator = activity.collaborators[indexPath.row]
                let cell = tableView.dequeueReusableCell(withIdentifier: "CollaboratorCell", for: indexPath)
                cell.textLabel?.text = collaborator.username
                return cell
                
            case .notifications:
                let notification = notifications[indexPath.row]
                let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationCell", for: indexPath)
                cell.textLabel?.text = notification.message
                
                let formatter = DateFormatter()
                formatter.dateStyle = .short
                formatter.timeStyle = .short
                cell.detailTextLabel?.text = formatter.string(from: notification.date)
                
                switch notification.type {
                case .stepCompleted:
                    cell.imageView?.image = UIImage(systemName: "checkmark.circle")
                    cell.imageView?.tintColor = .systemGreen
                case .postAdded:
                    cell.imageView?.image = UIImage(systemName: "doc.text")
                    cell.imageView?.tintColor = .systemBlue
                }
                return cell
            }
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            guard let detailSection = DetailSection(rawValue: indexPath.section) else { return }
            
            switch detailSection {
            case .steps:
                let selectedStep = activity.steps[indexPath.row]
                navigateToStepDetail(step: selectedStep, at: indexPath.row)
                
            case .collaborators:
                break // Optionally handle collaborator selection
                
            case .notifications:
                let selectedNotification = notifications[indexPath.row]
                if let post = selectedNotification.post {
                    print("Navigating to post details for post: \(post.content)") // Debug print
                    navigateToUpdateDetails(post: post)
                } else {
                    print("Selected notification does not contain a post.")
                }
            }
            
            tableView.deselectRow(at: indexPath, animated: true)
        }
        
        func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
            guard let detailSection = DetailSection(rawValue: indexPath.section), detailSection == .collaborators else {
                return nil
            }
            
            let removeAction = UIContextualAction(style: .destructive, title: "Remove") { (action, view, completionHandler) in
                self.removeCollaborator(at: indexPath.row)
                completionHandler(true)
            }
            
            return UISwipeActionsConfiguration(actions: [removeAction])
        }
    }

    // MARK: - StepDetailViewControllerDelegate

    extension ActivityDetailViewController: StepDetailViewControllerDelegate {
        func didUpdateStep(_ updatedStep: Step, at index: Int) {
            activity.steps[index] = updatedStep
            detailsTableView.reloadRows(at: [IndexPath(row: index, section: DetailSection.steps.rawValue)], with: .automatic)
            saveActivityChanges()
            updateProgress() // Update progress when a step is marked as completed
        }
   }
