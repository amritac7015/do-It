//
//  HomeViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/18/24.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{

    @IBOutlet weak var activitiesTableView: UITableView!
    
    @IBOutlet weak var emptyStateView: UIView!
    
    @IBOutlet weak var welcomeLabel: UILabel!
    
    var activities: [Activity] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "My Activities"

        activitiesTableView.delegate = self
        activitiesTableView.dataSource = self

        loadUserActivities()
        
        updateWelcomeMessage()

    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadUserActivities()
    }

    
    private func updateWelcomeMessage() {
        if let user = DataManager.shared.loadUser() {
            welcomeLabel?.text = "Welcome \(user.username)!"
        } else {
            welcomeLabel?.text = "Welcome!"
        }
    }


        func loadUserActivities() {
            activities = DataManager.shared.loadActivities()
            updateView()
        }

        func updateView() {
            activitiesTableView.reloadData()
            let hasActivities = !activities.isEmpty
            activitiesTableView.isHidden = !hasActivities
            emptyStateView.isHidden = hasActivities
        }

        // MARK: - UITableViewDataSource Methods

        // Number of rows in the table view
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return activities.count
        }

        // Configure each cell
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            let activity = activities[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier: "ActivityCell", for: indexPath)
            cell.textLabel?.text = activity.name
            cell.detailTextLabel?.text = activity.description
            cell.accessoryType = .disclosureIndicator
            return cell
        }

        // MARK: - UITableViewDelegate Methods

        // Handle row selection
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let selectedActivity = activities[indexPath.row]
            // Navigate to Activity Detail Screen
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let activityDetailVC = storyboard.instantiateViewController(withIdentifier: "ActivityDetailViewController") as? ActivityDetailViewController {
                activityDetailVC.activity = selectedActivity
                self.navigationController?.pushViewController(activityDetailVC, animated: true)
            }
        }

        func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {

            let leaveAction = UIContextualAction(style: .destructive, title: "Leave") { (action, view, completionHandler) in
                self.leaveActivity(at: indexPath)
                completionHandler(true)
            }

            let configuration = UISwipeActionsConfiguration(actions: [leaveAction])
            return configuration
        }

        func leaveActivity(at indexPath: IndexPath) {
            // Remove the activity from the array
            activities.remove(at: indexPath.row)
            // Update the table view
            activitiesTableView.deleteRows(at: [indexPath], with: .automatic)
            // Save the updated activities
            DataManager.shared.saveActivities(activities)
            // Update the view
            updateView()
        }

    }
