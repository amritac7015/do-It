//
//  AddStepsViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/18/24.
//

import UIKit

protocol AddStepsViewControllerDelegate: AnyObject {
    func didAddSteps(_ steps: [Step], activityName: String, activityDescription: String?)
}


class AddStepsViewController: UIViewController {

    // MARK: - Outlets
       
       /// TextField for entering the step name
       @IBOutlet weak var stepNameTextField: UITextField!
       /// TextView for entering the step description
       @IBOutlet weak var stepDescriptionTextView: UITextView!
       /// Button to add the step
       @IBOutlet weak var addStepButton: UIButton!
       /// TableView to display added steps
       @IBOutlet weak var stepsTableView: UITableView!
       
    // MARK: - Properties
       var steps: [Step] = [] // Received from PlanActivityViewController
       var collaborators: [User] = [] // Received from PlanActivityViewController
       weak var delegate: AddStepsViewControllerDelegate?
       
       /// The current activity being planned
       var activity: Activity! // <-- Added Property

       override func viewDidLoad() {
           super.viewDidLoad()
           self.navigationItem.title = "Add Steps"
           
           // Add the Next button to the navigation bar
           let nextBarButton = UIBarButtonItem(title: "Next", style: .done, target: self, action: #selector(nextBarButtonTapped))
           self.navigationItem.rightBarButtonItem = nextBarButton
           nextBarButton.isEnabled = false // Initially disabled
           
           // Configure UI elements
           addStepButton.layer.cornerRadius = 8
           stepDescriptionTextView.layer.borderColor = UIColor.lightGray.cgColor
           stepDescriptionTextView.layer.borderWidth = 1.0
           stepDescriptionTextView.layer.cornerRadius = 5.0
           stepDescriptionTextView.delegate = self
           
           // Set placeholder text
           stepDescriptionTextView.text = "Enter step description..."
           stepDescriptionTextView.textColor = UIColor.lightGray
           
           // Setup Table View
           stepsTableView.delegate = self
           stepsTableView.dataSource = self
           stepsTableView.register(UITableViewCell.self, forCellReuseIdentifier: "StepCell")
           
           // Add tap gesture to dismiss keyboard
           let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
           view.addGestureRecognizer(tapGesture)
       }
       
       // MARK: - Actions
       
       @IBAction func addStepButtonTapped(_ sender: UIButton) {
           // Validate step name
           guard let stepName = stepNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !stepName.isEmpty else {
               presentAlert(title: "Missing Step Name", message: "Please enter a step name.")
               return
           }
           
           // Optionally, validate step name length or characters
           if stepName.count > 50 {
               presentAlert(title: "Step Name Too Long", message: "Please enter a step name with fewer than 50 characters.")
               return
           }
           
           // Check for duplicate step names
           if steps.contains(where: { $0.name.lowercased() == stepName.lowercased() }) {
               presentAlert(title: "Duplicate Step", message: "This step has already been added.")
               return
           }
           
           // Get step description
           let stepDescription = stepDescriptionTextView.textColor == UIColor.lightGray ? nil : stepDescriptionTextView.text
           
           // Create a new Step object
           let newStep = Step(name: stepName, description: stepDescription ?? "", isCompleted: false)
           steps.append(newStep)
           
           // Reload the table view to display the new step
           stepsTableView.reloadData()
           
           print("AddStepsViewController: Added Step - \(newStep.name), Total Steps: \(steps.count)")

           // Clear input fields
           stepNameTextField.text = ""
           stepDescriptionTextView.text = "Enter step description..."
           stepDescriptionTextView.textColor = UIColor.lightGray
           
           // Enable the Next button
           self.navigationItem.rightBarButtonItem?.isEnabled = true
       }
       
       @objc func nextBarButtonTapped() {
           // Ensure there are steps to proceed
           guard !steps.isEmpty else {
               presentAlert(title: "No Steps Added", message: "Please add at least one step before proceeding.")
               return
           }
           
           // Pass the added steps back via delegate using activity property
           delegate?.didAddSteps(steps, activityName: activity.name, activityDescription: activity.description)
           
           // Do not navigate here; navigation is handled by PlanActivityViewController via the delegate method
           
           // Debugging Statement
           print("AddStepsViewController: Passing Steps Count: \(steps.count), Activity Name: \(activity.name), Description: \(activity.description ?? "No Description")")
       }
       
       // MARK: - Helper Methods
       
       func presentAlert(title: String, message: String) {
           let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
           alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
           present(alertController, animated: true, completion: nil)
       }
       
       @objc func dismissKeyboard() {
           view.endEditing(true)
       }
   }

   // MARK: - UITextViewDelegate

   extension AddStepsViewController: UITextViewDelegate {
       func textViewDidBeginEditing(_ textView: UITextView) {
           if textView.textColor == UIColor.lightGray {
               textView.text = ""
               textView.textColor = UIColor.black
           }
       }

       func textViewDidEndEditing(_ textView: UITextView) {
           if textView.text.isEmpty {
               textView.text = "Enter step description..."
               textView.textColor = UIColor.lightGray
           }
       }
   }

   // MARK: - UITableViewDataSource and UITableViewDelegate

   extension AddStepsViewController: UITableViewDataSource, UITableViewDelegate {
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return steps.count
       }

       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

           let step = steps[indexPath.row]
           let cell = tableView.dequeueReusableCell(withIdentifier: "StepCell", for: indexPath)
           cell.textLabel?.text = step.name
           cell.detailTextLabel?.text = step.description
           cell.accessoryType = step.isCompleted ? .checkmark : .none
           cell.selectionStyle = .none
           return cell
       }

       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           steps[indexPath.row].isCompleted.toggle()
           tableView.reloadRows(at: [indexPath], with: .automatic)
           tableView.deselectRow(at: indexPath, animated: true)
       }

       func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
           let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completionHandler) in
               self.steps.remove(at: indexPath.row)
               tableView.deleteRows(at: [indexPath], with: .automatic)
               
               // After deletion, check if Next button should be disabled
               if self.steps.isEmpty {
                   self.navigationItem.rightBarButtonItem?.isEnabled = false
               }
               
               completionHandler(true)
           }

           let configuration = UISwipeActionsConfiguration(actions: [deleteAction])
           return configuration
       }
   }

   // MARK: - AddCollaboratorsViewControllerDelegate

   extension AddStepsViewController: AddCollaboratorsViewControllerDelegate {
       func didAddCollaborators(_ collaborators: [User]) {
           self.collaborators = collaborators
       }
   }
