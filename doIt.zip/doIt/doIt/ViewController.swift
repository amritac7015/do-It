//
//  ViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/19/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

