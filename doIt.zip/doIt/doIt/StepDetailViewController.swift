//
//  StepDetailViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/20/24.
//

import UIKit

protocol StepDetailViewControllerDelegate: AnyObject {
    func didUpdateStep(_ updatedStep: Step, at index: Int)
}

class StepDetailViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

   
    @IBOutlet weak var stepNameLabel: UILabel!
    
    @IBOutlet weak var stepDescriptionLabel: UILabel!
    
    @IBOutlet weak var completionDescriptionTextView: UITextView!
    
    
    @IBOutlet weak var stepImageView: UIImageView!
    
    @IBOutlet weak var addPhotoButton: UIButton!
    
    @IBOutlet weak var completeStepButton: UIButton!
    
    var step: Step!
        weak var delegate: StepDetailViewControllerDelegate?
        var stepIndex: Int!
        
        // Placeholder label for UITextView
        private let placeholderLabel: UILabel = {
            let label = UILabel()
            label.text = "Enter completion details here..."
            label.textColor = .lightGray
            label.font = UIFont.systemFont(ofSize: 16)
            return label
        }()
    
    
    override func viewDidLoad() {
           super.viewDidLoad()
           
           setupUI()
           updateUIForStepCompletion()
       }
       
       // MARK: - UI Setup
       
       func setupUI() {
           self.navigationItem.title = "Step Details"
           
           stepNameLabel.text = step.name
           stepDescriptionLabel.text = step.description ?? "No description available."
           completionDescriptionTextView.text = step.completionDetails ?? ""
           
           // Add placeholder to UITextView
           if step.completionDetails?.isEmpty ?? true {
               completionDescriptionTextView.addSubview(placeholderLabel)
               placeholderLabel.translatesAutoresizingMaskIntoConstraints = false
               NSLayoutConstraint.activate([
                   placeholderLabel.topAnchor.constraint(equalTo: completionDescriptionTextView.topAnchor, constant: 8),
                   placeholderLabel.leadingAnchor.constraint(equalTo: completionDescriptionTextView.leadingAnchor, constant: 5),
                   placeholderLabel.trailingAnchor.constraint(equalTo: completionDescriptionTextView.trailingAnchor, constant: -5)
               ])
           }
           
           if let imageData = step.imageData, let image = UIImage(data: imageData) {
               stepImageView.image = image
               stepImageView.isHidden = false
           } else {
               stepImageView.isHidden = true
           }
           
           // Style the text view
           completionDescriptionTextView.layer.borderColor = UIColor.lightGray.cgColor
           completionDescriptionTextView.layer.borderWidth = 0.5
           completionDescriptionTextView.layer.cornerRadius = 5
           completionDescriptionTextView.delegate = self
       }
       
       func updateUIForStepCompletion() {
           if step.isCompleted {
               completeStepButton.isEnabled = false
               addPhotoButton.isHidden = true
               completionDescriptionTextView.isEditable = false
               placeholderLabel.isHidden = true
           } else {
               completeStepButton.isEnabled = true
               addPhotoButton.isHidden = false
               completionDescriptionTextView.isEditable = true
               placeholderLabel.isHidden = !(completionDescriptionTextView.text.isEmpty)
           }
       }
       
       // MARK: - Actions
       
       @IBAction func addPhotoButtonTapped(_ sender: UIButton) {
           presentImagePickerOptions()
       }
       
       @IBAction func completeStepButtonTapped(_ sender: UIButton) {
           // Validate completion description
           guard let completionText = completionDescriptionTextView.text, !completionText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
               presentAlert(title: "Incomplete", message: "Please enter completion details before marking the step as complete.")
               return
           }
           
           // Mark the step as complete
           step.isCompleted = true
           step.completionDetails = completionText
           delegate?.didUpdateStep(step, at: stepIndex)
           updateUIForStepCompletion()
       }
       
       // MARK: - Image Picker
       
       func presentImagePickerOptions() {
           let imagePicker = UIImagePickerController()
           imagePicker.delegate = self
           
           let alertController = UIAlertController(title: "Add Photo", message: "Choose a source", preferredStyle: .actionSheet)
           
           // Camera option
           if UIImagePickerController.isSourceTypeAvailable(.camera) {
               let cameraAction = UIAlertAction(title: "Camera", style: .default) { _ in
                   imagePicker.sourceType = .camera
                   imagePicker.cameraCaptureMode = .photo
                   imagePicker.modalPresentationStyle = .fullScreen
                   self.present(imagePicker, animated: true, completion: nil)
               }
               alertController.addAction(cameraAction)
           }
           
           // Photo Library option
           if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
               let libraryAction = UIAlertAction(title: "Photo Library", style: .default) { _ in
                   imagePicker.sourceType = .photoLibrary
                   self.present(imagePicker, animated: true, completion: nil)
               }
               alertController.addAction(libraryAction)
           }
           
           // Cancel option
           let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
           alertController.addAction(cancelAction)
           
           // For iPad compatibility
           if let popoverController = alertController.popoverPresentationController {
               popoverController.sourceView = addPhotoButton
               popoverController.sourceRect = addPhotoButton.bounds
           }
           
           present(alertController, animated: true, completion: nil)
       }
       
       // MARK: - UIImagePickerControllerDelegate Methods
       
       func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
           picker.dismiss(animated: true, completion: nil)
           
           // Retrieve the selected image
           if let image = info[.originalImage] as? UIImage {
               stepImageView.image = image
               stepImageView.isHidden = false
               
               // Convert image to Data and save it in the step
               if let imageData = image.jpegData(compressionQuality: 0.8) {
                   step.imageData = imageData
                   delegate?.didUpdateStep(step, at: stepIndex)
               }
           }
       }
       
       func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
           picker.dismiss(animated: true, completion: nil)
       }
       
       // MARK: - Helper Methods
       
       func presentAlert(title: String, message: String) {
           let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
           let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
           alertController.addAction(okAction)
           present(alertController, animated: true, completion: nil)
       }
   }

   // MARK: - UITextViewDelegate

   extension StepDetailViewController: UITextViewDelegate {
       func textViewDidChange(_ textView: UITextView) {
           // Show or hide placeholder based on text
           placeholderLabel.isHidden = !textView.text.isEmpty
       }
   }
