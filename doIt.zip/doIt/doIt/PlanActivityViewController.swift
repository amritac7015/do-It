//
//  PlanActivityViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/21/24.
//

import UIKit



class PlanActivityViewController: UIViewController {
    
    // MARK: - Outlets
    
    /// TextField for entering the activity name
    
    @IBOutlet weak var activityNameTextField: UITextField!
    /// TextView for entering the activity description
    @IBOutlet weak var activityDescriptionTextView: UITextView!
    
    // MARK: - Properties
        var steps: [Step] = []
        var collaborators: [User] = []
        var activityName: String = ""
        var activityDescription: String?
        
        // MARK: - View Lifecycle
        override func viewDidLoad() {
            super.viewDidLoad()

            // Set the title of the navigation bar
            self.navigationItem.title = "Plan Activity"
            
            // Add a Next button to the navigation bar to proceed to the next step
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Next", style: .done,
                                                                     target: self, action: #selector(nextButtonTapped))
            
            // Configure the appearance of the activityDescriptionTextView
            activityDescriptionTextView.layer.borderColor = UIColor.lightGray.cgColor
            activityDescriptionTextView.layer.borderWidth = 1.0
            activityDescriptionTextView.layer.cornerRadius = 5.0
            
            // Set the delegate to handle placeholder functionality
            activityDescriptionTextView.delegate = self
            
            // Initialize the placeholder text and color
            activityDescriptionTextView.text = "Enter activity description..."
            activityDescriptionTextView.textColor = UIColor.lightGray
        }
        
        // MARK: - Actions
        
        /// Action triggered when the Next button is tapped
        @objc func nextButtonTapped() {
            // Validate that the activity name is not empty
            guard let name = activityNameTextField.text, !name.trimmingCharacters(in: .whitespaces).isEmpty else {
                presentAlert(title: "Missing Name", message: "Please enter an activity name.")
                return
            }
            
            // Handle placeholder text for description
            var description = activityDescriptionTextView.text
            if description == "Enter activity description..." {
                description = nil
            }
            
            // Set activityName and activityDescription properties
            self.activityName = name
            self.activityDescription = description
            
            // Create an Activity object
            let currentActivity = Activity(name: self.activityName, description: self.activityDescription, collaborators: self.collaborators, steps: self.steps)
            
            // Navigate to AddStepsViewController
            navigateToAddSteps(with: currentActivity)
        }
        
        // MARK: - Navigation Methods
        
        /// Navigates to AddStepsViewController
        func navigateToAddSteps(with activity: Activity) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let addStepsVC = storyboard.instantiateViewController(withIdentifier: "AddStepsViewController") as? AddStepsViewController {
                addStepsVC.delegate = self
                addStepsVC.steps = self.steps // Pass existing steps if any
                addStepsVC.collaborators = self.collaborators
                addStepsVC.activity = activity
                self.navigationController?.pushViewController(addStepsVC, animated: true)
                
                // Debugging Statement
                print("PlanActivityViewController: Navigated to AddStepsViewController, Delegate Set.")
            }
        }
        
        /// Navigates to AddCollaboratorsViewController
        func navigateToAddCollaborators() {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let addCollaboratorsVC = storyboard.instantiateViewController(withIdentifier: "AddCollaboratorsViewController") as? AddCollaboratorsViewController {
                addCollaboratorsVC.steps = self.steps
                addCollaboratorsVC.collaborators = self.collaborators
                addCollaboratorsVC.activityName = self.activityName
                addCollaboratorsVC.activityDescription = self.activityDescription
                addCollaboratorsVC.delegate = self // Set delegate if needed
                self.navigationController?.pushViewController(addCollaboratorsVC, animated: true)
                
                // Debugging Statement
                print("PlanActivityViewController: Navigated to AddCollaboratorsViewController with Steps Count: \(steps.count)")
            }
        }
        
        // MARK: - Helper Methods
        
        /// Presents an alert with a given title and message
        /// - Parameters:
        ///   - title: The title of the alert
        ///   - message: The message body of the alert
        func presentAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
        }
    }

    // MARK: - UITextViewDelegate

    extension PlanActivityViewController: UITextViewDelegate {
        
        /// Called when the user begins editing the UITextView
        func textViewDidBeginEditing(_ textView: UITextView) {
            if textView.textColor == UIColor.lightGray {
                // Clear placeholder text and set text color to black
                textView.text = ""
                textView.textColor = UIColor.black
            }
        }
        
        /// Called when the user finishes editing the UITextView
        func textViewDidEndEditing(_ textView: UITextView) {
            if textView.text.isEmpty {
                // Restore placeholder text and set text color to light gray
                textView.text = "Enter activity description..."
                textView.textColor = UIColor.lightGray
            }
        }
    }

    // MARK: - AddStepsViewControllerDelegate

    extension PlanActivityViewController: AddStepsViewControllerDelegate {
        
        /// Receives the added steps from AddStepsViewController
        func didAddSteps(_ steps: [Step], activityName: String, activityDescription: String?) {
            self.steps = steps
            self.activityName = activityName
            self.activityDescription = activityDescription
            
            // Debugging Statement
            print("PlanActivityViewController: Received Steps Count: \(steps.count), Activity Name: \(activityName), Description: \(activityDescription ?? "No Description")")
            
            // Navigate to AddCollaboratorsViewController after receiving steps
            navigateToAddCollaborators()
        }
    }

    // MARK: - AddCollaboratorsViewControllerDelegate

    extension PlanActivityViewController: AddCollaboratorsViewControllerDelegate {
        
        /// Receives the added collaborators from AddCollaboratorsViewController
        func didAddCollaborators(_ collaborators: [User]) {
            self.collaborators = collaborators
            // Optionally, update UI or perform additional actions
                }
            }
