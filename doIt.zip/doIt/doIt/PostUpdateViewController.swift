//
//  PostUpdateViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/10/24.
//

import UIKit

class PostUpdateViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var activityTextField: UITextField!
    @IBOutlet weak var postTextView: UITextView!
    @IBOutlet weak var postButton: UIButton!
    
    // MARK: - Properties
        var activities: [Activity] = []
        var selectedActivity: Activity?
        
        // Picker View for Activity Selection
        private let activityPicker = UIPickerView()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            self.navigationItem.title = "Post Update"
            
            configurePostButton()
            configurePostTextView()
            configureActivityTextField()
            loadActivities()
        }
        
        // MARK: - Configuration Methods
        
        private func configurePostButton() {
            postButton.layer.cornerRadius = 8
            postButton.addTarget(self, action: #selector(postButtonTapped), for: .touchUpInside)
        }
        
        private func configurePostTextView() {
            postTextView.layer.borderColor = UIColor.lightGray.cgColor
            postTextView.layer.borderWidth = 1.0
            postTextView.layer.cornerRadius = 5.0
            postTextView.delegate = self
            postTextView.text = "Enter your post here..."
            postTextView.textColor = UIColor.lightGray
        }
        
        private func configureActivityTextField() {
            activityPicker.delegate = self
            activityPicker.dataSource = self
            activityTextField.inputView = activityPicker
            
            let toolbar = UIToolbar()
            toolbar.sizeToFit()
            let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donePicking))
            toolbar.setItems([doneButton], animated: false)
            activityTextField.inputAccessoryView = toolbar
        }
        
        // MARK: - Data Loading
        
        private func loadActivities() {
            activities = DataManager.shared.loadActivities()
            activityPicker.reloadAllComponents()
            
            if activities.isEmpty {
                activityTextField.text = "No activities available"
                activityTextField.isEnabled = false
            } else {
                selectedActivity = activities.first
                activityTextField.text = selectedActivity?.name
                activityTextField.isEnabled = true
            }
        }
        
        // MARK: - Actions
        
        @objc private func donePicking() {
            activityTextField.resignFirstResponder()
        }
        
        @objc private func postButtonTapped() {
            guard let activity = selectedActivity else {
                presentAlert(title: "No Activity Selected", message: "Please select an activity to post about.")
                return
            }
            
            guard let postContent = postTextView.text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !postContent.isEmpty,
                  postContent != "Enter your post here..." else {
                presentAlert(title: "Empty Post", message: "Please enter some content for your post.")
                return
            }
            
            guard let currentUser = DataManager.shared.loadUser() else {
                presentAlert(title: "User Not Found", message: "Please log in or create a profile.")
                return
            }
            
            // Create a new Post with detailed message
            let newPost = Post(
                author: currentUser,
                content: String(postContent.prefix(100)) + "...", // Show the first 100 characters as a preview
                detailedMessage: postContent, // Store the full post content
                date: Date()
            )
            
            // Update Activity with the New Post
            var updatedActivity = activity
            updatedActivity.posts.append(newPost)
            DataManager.shared.updateActivity(updatedActivity)
            
            // Create a Notification for the Post
            let notificationMessage = "\(currentUser.username) posted an update to \(activity.name)."
            let notification = NotificationItem(
                type: .postAdded,
                message: notificationMessage,
                detailedMessage: newPost.detailedMessage ?? "No detailed message provided",
                date: Date(),
                author: currentUser.username
            )
            DataManager.shared.addNotification(notification)
            
            presentAlert(title: "Success", message: "Your post has been added successfully.")
            postTextView.text = "Enter your post here..."
            postTextView.textColor = UIColor.lightGray
        }
        
        private func presentAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController, animated: true, completion: nil)
        }
    }

    // MARK: - UITextViewDelegate

    extension PostUpdateViewController: UITextViewDelegate {
        func textViewDidBeginEditing(_ textView: UITextView) {
            if textView.textColor == UIColor.lightGray {
                textView.text = ""
                textView.textColor = UIColor.black
            }
        }

        func textViewDidEndEditing(_ textView: UITextView) {
            if textView.text.isEmpty {
                textView.text = "Enter your post here..."
                textView.textColor = UIColor.lightGray
            }
        }
    }

    // MARK: - UIPickerViewDataSource & UIPickerViewDelegate

    extension PostUpdateViewController: UIPickerViewDataSource, UIPickerViewDelegate {
        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return activities.count
        }
        
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return activities[row].name
        }
        
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            guard row < activities.count else {
                print("Error: Selected row \(row) is out of range. Available activities count: \(activities.count)")
                return
            }
            
            selectedActivity = activities[row]
            activityTextField.text = activities[row].name
        }
    }
