//
//  AddCollaboratorsViewController.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/18/24.
//

import UIKit

/// Delegate protocol to inform PlanActivityViewController about added collaborators (optional)
protocol AddCollaboratorsViewControllerDelegate: AnyObject {
    func didAddCollaborators(_ collaborators: [User])
}
/// ViewController for adding collaborators to an activity
class AddCollaboratorsViewController: UIViewController {
    
    // MARK: - Outlets
    
    /// TableView to display the list of collaborators
    @IBOutlet weak var collaboratorsTableView: UITableView!
    
    /// Label to display when there are no collaborators
    @IBOutlet weak var emptyStateLabel: UILabel!
    
    // MARK: - Properties
        weak var delegate: AddCollaboratorsViewControllerDelegate?
        var collaborators: [User] = []
        var steps: [Step] = []
        var activityName: String = ""
        var activityDescription: String?
        
        // MARK: - View Lifecycle
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Set up the navigation bar
            configureNavigationBar()
            
            // Set navigation bar title
            self.navigationItem.title = "Add Collaborators"
            
            // Set up TableView
            collaboratorsTableView.delegate = self
            collaboratorsTableView.dataSource = self
            collaboratorsTableView.tableFooterView = UIView() // Remove empty cells
            
            // Update UI based on collaborators count
            updateEmptyState()
        }
        
        // MARK: - Navigation Bar Configuration
        
        /// Configures the navigation bar with Cancel and Save buttons
        func configureNavigationBar() {
            // Left Bar Button: Cancel
            let cancelButton = UIBarButtonItem(barButtonSystemItem: .cancel,
                                               target: self,
                                               action: #selector(cancelButtonTapped))
            self.navigationItem.leftBarButtonItem = cancelButton
            
            // Right Bar Button: Save
            let saveButton = UIBarButtonItem(title: "Save",
                                             style: .done,
                                             target: self,
                                             action: #selector(saveButtonTapped))
            self.navigationItem.rightBarButtonItem = saveButton
        }
        
        // MARK: - Actions
        
        /// Action for Cancel button
        @objc func cancelButtonTapped() {
            // Option 1: Dismiss if presented modally
            // self.dismiss(animated: true, completion: nil)
            
            // Option 2: Pop if pushed onto the navigation stack
            self.navigationController?.popViewController(animated: true)
        }
        
        /// Action for Save button
        @objc func saveButtonTapped() {
            // Validate that at least one collaborator is added
            guard !collaborators.isEmpty else {
                presentAlert(title: "No Collaborators Added", message: "Please add at least one collaborator before saving.")
                return
            }
            
            // Notify delegate about the added collaborators
            delegate?.didAddCollaborators(collaborators)
            
            // Save the activity using DataManager
            saveActivity()
            
            // Redirect to Home Page (Assuming Home Page is the Root View Controller)
            self.navigationController?.popToRootViewController(animated: true)
        }
        
        /// Action for Add Collaborator button (Floating Action Button)
        @IBAction func addCollaboratorButtonTapped(_ sender: UIButton) {
            presentAddCollaboratorAlert()
        }
        
        // MARK: - Helper Methods
        
        /// Presents an alert to add a new collaborator
        func presentAddCollaboratorAlert() {
            let alert = UIAlertController(title: "New Collaborator",
                                          message: "Enter collaborator's username.",
                                          preferredStyle: .alert)
            
            alert.addTextField { (textField) in
                textField.placeholder = "Username"
            }
            
            let addAction = UIAlertAction(title: "Add", style: .default) { [weak self] (_) in
                guard let self = self else { return }
                guard let username = alert.textFields?[0].text?.trimmingCharacters(in: .whitespacesAndNewlines),
                      !username.isEmpty else {
                    self.presentAlert(title: "Missing Username",
                                      message: "Please enter a collaborator's username.")
                    return
                }
                
                // Optional: Validate username format
                if !self.isValidUsername(username) {
                    self.presentAlert(title: "Invalid Username",
                                      message: "Username must be 3-15 characters long and contain only letters, numbers, or underscores.")
                    return
                }
                
                // Optional: Prevent duplicates
                if self.collaborators.contains(where: { $0.username.lowercased() == username.lowercased() }) {
                    self.presentAlert(title: "Duplicate Collaborator",
                                      message: "A collaborator with this username already exists.")
                    return
                }
                
                let profileImageData = UIImage(named: "defaultProfileImage")?.pngData()
                let newCollaborator = User(username: username, profileImage: profileImageData, notificationsEnabled: false)
                self.collaborators.append(newCollaborator)
                self.collaboratorsTableView.reloadData()
                self.updateEmptyState()
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            
            alert.addAction(addAction)
            alert.addAction(cancelAction)
            
            present(alert, animated: true, completion: nil)
        }
        
        /// Validates the username format
        func isValidUsername(_ username: String) -> Bool {
            let regex = "^[a-zA-Z0-9_]{3,15}$"
            let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
            return predicate.evaluate(with: username)
        }
        
        /// Saves the activity using DataManager
        func saveActivity() {
            // Use passed-in activityName, activityDescription, steps, collaborators
            let activity = Activity(name: activityName, description: activityDescription, collaborators: collaborators, steps: steps)
            var currentActivities = DataManager.shared.loadActivities()
            currentActivities.append(activity)
            DataManager.shared.saveActivities(currentActivities)
            
            print("Saved Activity: \(activity.name), Steps Count: \(activity.steps.count)")
        }
        
        /// Presents a simple alert with a title and message
        func presentAlert(title: String, message: String) {
            let alertController = UIAlertController(title: title,
                                                    message: message,
                                                    preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK",
                                                    style: .default,
                                                    handler: nil))
            present(alertController, animated: true, completion: nil)
        }
        
        /// Updates the visibility of the empty state label based on collaborators count
        func updateEmptyState() {
            emptyStateLabel.isHidden = !collaborators.isEmpty
        }
    }

    // MARK: - UITableViewDataSource

    extension AddCollaboratorsViewController: UITableViewDataSource {
        
        /// Returns the number of collaborators
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return collaborators.count
        }
        
        /// Configures each cell with collaborator data
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CollaboratorCell", for: indexPath)
            let collaborator = collaborators[indexPath.row]
            cell.textLabel?.text = collaborator.username
            cell.accessoryType = .none
            return cell
        }
    }

    // MARK: - UITableViewDelegate

    extension AddCollaboratorsViewController: UITableViewDelegate {
        
        /// Enables swipe to delete functionality
        func tableView(_ tableView: UITableView,
                       commit editingStyle: UITableViewCell.EditingStyle,
                       forRowAt indexPath: IndexPath) {
            if editingStyle == .delete {
                // Remove the collaborator from the data source
                collaborators.remove(at: indexPath.row)
                
                // Delete the row from the table view
                tableView.deleteRows(at: [indexPath], with: .automatic)
                
                // Update empty state if needed
                updateEmptyState()
            }
        }
        
        /// Optionally, handle selection of a collaborator for editing
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            // Deselect the row
            tableView.deselectRow(at: indexPath, animated: true)
            
            // Optionally, present an edit option or detail view
            // For example, push a CollaboratorDetailViewController
        }
    }
