//
//  DataManager.swift
//  doIt
//
//  Created by Amrita Choudhary on 10/19/24.
//

// DataManager.swift
import Foundation

class DataManager {
    
    static let shared = DataManager()
    
    private let activitiesKey = "activitiesKey"
    private let notificationsKey = "notificationsKey"
    private let userKey = "currentUserKey"

    
    private init() {}
    
    // Save activities
    func saveActivities(_ activities: [Activity]) {
        if let data = try? JSONEncoder().encode(activities) {
            UserDefaults.standard.set(data, forKey: activitiesKey)
        }
    }
    
    // Load activities
    func loadActivities() -> [Activity] {
        if let data = UserDefaults.standard.data(forKey: activitiesKey),
           let activities = try? JSONDecoder().decode([Activity].self, from: data) {
            return activities
        }
        return []
    }
    
    // Update or Add an Activity
    func updateActivity(_ updatedActivity: Activity) {
        var activities = loadActivities()
        
        if let index = activities.firstIndex(where: { $0.id == updatedActivity.id }) {
            // Update existing activity
            activities[index] = updatedActivity
        } else {
            // Add new activity
            activities.append(updatedActivity)
        }
        
        saveActivities(activities)
    }
    
    // Delete an Activity
    func deleteActivity(_ activity: Activity) {
        var activities = loadActivities()
        
        if let index = activities.firstIndex(where: { $0.id == activity.id }) {
            activities.remove(at: index)
            saveActivities(activities)
        }
    }
    
    
    // MARK: - Notifications
        
        func loadNotifications() -> [NotificationItem] {
            if let data = UserDefaults.standard.data(forKey: notificationsKey),
               let notifications = try? JSONDecoder().decode([NotificationItem].self, from: data) {
                print("DataManager: Loaded Notifications - Count: \(notifications.count)")
                return notifications
            }
            print("DataManager: No notifications found.")
            return []
        }
        
        func saveNotifications(_ notifications: [NotificationItem]) {
            do {
                let data = try JSONEncoder().encode(notifications)
                UserDefaults.standard.set(data, forKey: notificationsKey)
                print("DataManager: Saved Notifications - Count: \(notifications.count)")
            } catch {
                print("DataManager: Failed to encode notifications - \(error.localizedDescription)")
            }
        }
        
        func addNotification(_ notification: NotificationItem) {
            var currentNotifications = loadNotifications()
            currentNotifications.append(notification)
            saveNotifications(currentNotifications)
            print("DataManager: Added Notification - \(notification.message)")
        }
    
    
    
    func saveUser(_ user: User) {
        UserDefaults.standard.set(user.username, forKey: "username")
        UserDefaults.standard.set(user.notificationsEnabled, forKey: "notificationsEnabled")
        if let imageData = user.profileImage {
            UserDefaults.standard.set(imageData, forKey: "profileImage")
        }
        UserDefaults.standard.synchronize()
    }

        
    func loadUser() -> User? {
        guard let username = UserDefaults.standard.string(forKey: "username") else { return nil }
        let notificationsEnabled = UserDefaults.standard.bool(forKey: "notificationsEnabled")
        let profileImage = UserDefaults.standard.data(forKey: "profileImage")
        
        return User(username: username, profileImage: profileImage, notificationsEnabled: notificationsEnabled)
    }

}
